package com.greedy.section02.string;

public class Application2 {
	
	public static void main(String[] args) {
		
		/* 문자열 객체를 만드는 방법 
		 * "" 리터럴 형태 : 동일한 값을 가지는 인스턴스를 단일 인스턴스로 관리한다. (singleton)
		 * new String("문자열") :  매번 새로운 인스턴스를 생성한다. // 주소값이 달라짐
		 * */
		
		String str1 = "java";
		String str2 = "java";
		String str3 = new String("java");
		String str4 = new String("java");
		
		/* 리터럴 형태로 만든 문자열은 인스턴스는 동일한 값을 가지는 인스턴스는 하나의 인스턴스로 관리한다.
		 * 따라서 주소값을 비교하는 == 연산으로 비교 시 서로 동일한 stack에 저장된 주소를 비교하여 true를 반환한다.
		 * */
		System.out.println("str1 == str2 : " + (str1 == str2));

		System.out.println("str2 == str3 : " + (str2 == str3));
		//둘이 비교하면 다름 3은 java의 heap영역에 주소값을 새로 만들어서 사용하는것이라서 즉, 주소값비교
		
		System.out.println("str1의 hasCode : " + System.identityHashCode(str1.hashCode()));
		// 이렇게도 확인가능하다
//		System.out.println("str2의 hasCode : " + str1.hashCode());
		System.out.println("str2의 hasCode : " + str2.hashCode());
		System.out.println("str3의 hasCode : " + str3.hashCode());
		System.out.println("str4의 hasCode : " + str4.hashCode());
		
		/* 문자열은 불변이라는 특징을 가진다.
		 * 기존 문자열에 +연산을 수행하는 경우 문자열을 수정하는 것이 아닌 새로운 문자열을 할당하게된다.
		 * */
		str2 += "oracle"; // 기존에 있던값을 넣어주는게아니라 새로운 주소값을 넣어서 변경되는것
		
		System.out.println("str1 == str2 : " + (str1 == str2)); // 그래서 비교하면 주소값이 바뀐결과로 false가 나옴
		
		System.out.println("str1.equals(str3) : " + (str1.equals(str3)));
		System.out.println("str1.equals(str3) : " + (str1.equals(str4)));
			//안에있는 값이 같으면 다같은애들로 바라보기위해서 equals 사용
		
		/* new java.util.Scanner(System.in).nextLine() 을 이용해서 문자열을 입력받는 경우
		 * substring으로 잘라내기해서 새로운 문자열을 생성 후 반환하기 때문에
		 * new String()으로 인스턴스를 생성한 것과 동일한 것으로 볼 수 있다.*/
	}

}
