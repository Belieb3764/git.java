package com.greedy.section01.object.book.vo;

import java.util.Objects;

public class BookVO {
	
	
	private int number;
	private String title;
	private String author;
	private int price;
	
	
	
	
	
	public BookVO() {
		super();
	}
	




	public BookVO(int number, String title, String author, int price) {
		super();
		this.number = number;
		this.title = title;
		this.author = author;
		this.price = price;
	}






	public int getNumber() {
		return number;
	}





	public void setNumber(int number) {
		this.number = number;
	}





	public String getTitle() {
		return title;
	}





	public void setTitle(String title) {
		this.title = title;
	}





	public String getAuthor() {
		return author;
	}





	public void setAuthor(String author) {
		this.author = author;
	}





	public int getPrice() {
		return price;
	}





	public void setPrice(int price) {
		this.price = price;
	}





	@Override
	public String toString() {
		return "BookVO [number=" + number + ""
			+ ", title=" + title 
			+ ", author=" + author 
			+ ", price=" + price + "]";
	}





	@Override
	public int hashCode() {
		return Objects.hash(author, number, price, title);
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookVO other = (BookVO) obj;
		return Objects.equals(author, other.author) && number == other.number && price == other.price
				&& Objects.equals(title, other.title);
	}
	
	
	//동등객체는 값이 다 같고 동일객체로 바라보고싶은거 그런데 주소값이 달라서 해쉬코드까지..세트다..?
	
	
//	@Override
//	public boolean equals(Object obj) { //현재의 obj는 다형성때문에 Object 내용만 가져올 수 있음
//		
//		/* 두 인스턴스의 주소가 같으면 이후 다른 내용을 비교할 것도 없이 true를 반환한다. */
//		if(this == obj) { //주소값이 같은지 물어보는것
//			return true;
//		}
//		
//		/* this는 인스턴스가 생성되면 주소값이 저장된다. null일 수 없다. */
//		if(obj == null) {
//			return false;
//		}
//		
//		/* 전달받은 레퍼런스 변수안에 있는 각 필드별로 비교를 시작 */
//		BookVO other = (BookVO) obj;
//		
//		/* number 필드의 값이 서로 같지 않은 경우 서로 다른 인스턴스이다. */
//		if(this.number != other.number) {
//			return false;
//		}
//		
//		if(this.title == null) {
//			/* title 필드가 null인경우 다른 인스턴스의 title이 null이 아니면 false반환 */
//			if(other.title != null) {
//				return false;
//			}
//		} else if(!this.title.equals(other.title)) {
//			//논리부정을 해준이유는 이두개가 같으면 안으로들어오고 같지않으면 false return false값 얻으려고
//			return false;
//		
//		}
//			if(this.author == null) {
//				
//				if(other.author != null) {
//					return false;
//				}
//			} else if(!this.author.equals(other.author)) {
//				return false;
//			}
//			
//			if(this.price != other.price) {
//				return false;
//			}
//		
//			/* 모든 조건을 통과하면 두 인스턴스의 모든 필드는 같은 값을 가지므로 true반환*/
//		return true;  //여기까지 왔다는건 true라는것 값이 똑같다는것 
//	}
//	
//	@Override
//	public int hashCode() {
//		
//		/* 곱셈 연산을 누적시켜야 하기 때문에 0이 아닌 값으로 초기화 */
//		int result = 1;
//		
//		final int PRIME = 31;
//		
//		result = PRIME * result + this.number;
//		result = PRIME * result + this.title.hashCode(); // 문자열이여서 
//		result = PRIME * result + this.author.hashCode();
//		result = PRIME * result + this.price;
//		//오버플로우가 일어나서 음수도 나올수있는데 그건 신경쓰지말고 값만비교할것
//		
//		return result;
//		
//	}
	//31이 내부안에있는 소수를 찾아내는 확률
	//소수는 막을수는없지만 확률을 낮춰주는 용도

}
