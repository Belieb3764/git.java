package com.greedy.section01.literal;

public class Application2 {
	/* public static void main(String[] args) { }는 실행용 메소드라는 이름으로
	 * 
	 * 각 클래스마다 하나씩 존재하며 클래스를 실행했을 떄 맨처음 실행되는 메소드(기능)을 말한다.
	 * */
	public static void main(String[] args) {
		
		/* 값을 직접 연산하여 출력 
		 * 이 때 값의 형태에 따라 사용할 수 있는 연산자의 종류(+,-,*,/,%)와 연산의 결과가 달라진다.
		 * */
		System.out.println("============ 정수와 정수의 연산 ============");
		System.out.println(123 + 456);
		System.out.println(123 - 23);
		System.out.println(123 * 10);
		System.out.println(123 / 10);
		System.out.println(123 % 10);
		
		
		System.out.println("============ 실수와 실수의 연산 ============");
		System.out.println(1.23 + 1.23);
		System.out.println(1.23 - 0.23);
		System.out.println(1.23 * 10.0);
		System.out.println(1.23 / 10.0);
		System.out.println(1.23 % 1.0);
		
		/* 정수와 실수의 연산도 수학에서 사용하는 사칙연산에 나머지를 구하는 연산을 사용할 수 있고,
		 * 정수와 실수의 연산의 결과는 항상 실수가 나온다.
		 * */
		System.out.println("============ 정수와 실수의 연산 ============");
		System.out.println(123 + 0.5);
		System.out.println(123 - 0.5);
		System.out.println(123 * 0.5);
		System.out.println(123 / 0.5);
		System.out.println(123 % 0.5);
		
		/*
		 * 문자와 문자의 연산
		 * 문자끼리의 연산도 사칙연산(+,-,*,/)에 mod연산(%)까지 가능하다.
		 * */
		System.out.println("============ 문자와 문자의 연산 ============");
		System.out.println('a' + 'b');
		System.out.println('a' - 'b');
		System.out.println('a' * 2);
		System.out.println('a' / 2);
		System.out.println('a' % 2);
		
		System.out.println("============ 문자와 정수의 연산 ============");
		System.out.println('a' + 1);
		System.out.println('a' - 1);
		System.out.println('a' * 2);
		System.out.println('a' / 2);
		System.out.println('a' % 2);
		
		System.out.println("============ 문자와 실수의 연산 ============");
		System.out.println('a' + 1.0);
		System.out.println('a' - 1.0);
		System.out.println('a' * 2.0);
		System.out.println('a' / 2.0);
		System.out.println('a' % 2.0);
		
		
		/* 결론은 문자는 내부적으로 숫자 취급을 한다.
		 * 그래서 지금까지 연산은 숫자끼리의 연산을 본 것이고, 숫자(정수 혹은 실수)형태의 값은 
		 * 수학의 사칙연산과 mod연산이 가능하다. 
		 * */
	
		/* 문자열과 다른 형태의 값 연산
		 * --> 문자열과의 연산은 '+' 연산만 가능하다.
		 * --> 문자열과 문자열의 연산도 '+' 연산만 가능하다. = 문자열 합치기
		 * */
		System.out.println("============ 문자열와 문자열의 연산 ============");
		System.out.println("hello" + "world");
//		System.out.println("hello" - "world"); // java.lang.String <- package 보여야함 
//		System.out.println("hello" * "world"); // 에러발생
//		System.out.println("hello" / "world"); // 에러발생
//		System.out.println("hello" % "world"); // 에러발생
		
		System.out.println("============ 문자열와 다른 형태의 연산 ============");
		System.out.println("helloworld" + 123);
		System.out.println("helloworld" + 123.456);
		System.out.println("helloworld" + 'a');
		System.out.println("helloworld" + true);
		// 수행의 결과는 무조건 문자열
		
		System.out.println("123" + "456");
		
		/* 논리값 연산
		 * 논리값과 다른자료형의 연산은 정수, 실수, 문자 모두 연산자 사용이 불가능하다.
		 *
		 * 단, 논리값과 문자열 '+'연산만 가능하다.
		 * */
//		System.out.println(true + false); 에러발생
//		System.out.println(true + 1); //에러발생
//		System.out.println(true + 1.0); //에러발생
//		System.out.println(true + 'a'); // 문자는 내부적으로 숫자 취급을 하기 때문에 결국 논리값과 숫자의 연산과 동일한 의미
		System.out.println(true + "a"); // '+' 연산만 가능
	
	}
}
