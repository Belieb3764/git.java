package com.greedy.section02.varlable;

public class Application3 {
	
//	int age = 20;
	
	public static void main(String[] args) {
		int age = 20;
//		int age = 20; // 동일한 변수명을 가지므로 에러 발생
		
//		int true = 1; // 예약어 사용 불가

		int Age = 20;  // 위에서 만든 age와 다른 것으로 취급한다.
		int True = 10; // 예약어 true와 다른 것으로 취급
		
//		int 1age = 20; // 숫자로 시작해서 에러 발생
		int age1 = 20; // 숫자가 처음에 시작하지 않으면 섞어서 사용도 가능
		
//		int sh@rp = 20;
		int _age = 20;
		int $harp = 20; 
		
		/* 암묵적인 규칙*/
		int asjdkjaskjhajdhakwhdskjadhkjasjhkajdsh;
		
		/* 변수명이 합성어로 이루어진 경우 첫 단어는 소문자, 두번째 단어는 대문자로 시작
		 * --> 자바에서는 클래스명만 유일하게 대문자로 시작한다.!!!!!!!!!!!
		 * */
		int maxAge = 20;
		int minAge = 10;
		
		String user_name; // 에러가 발생하지 않지만 이렇게 하지말고
		String userName;  // 이게 올바른 표현

		String s;
		String name; 
		
		int sum = 0;
		int max = 10;
		int min = 0;
		int count = 1;
		
		String goHome;
		String home;
		
		boolean isAlive  = true; // 긍정형으로 표현하는것이 더 나음
		boolean isDead = false;
	}

}
