package com.greedy.level01.basic;

public class Application1 {
	
	/* 실행용 메소드 */
	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		calc.checkMethod();
		
		String result = calc.sumTwoNumbers(10, 20);
		
		System.out.println(result);
		
		String result2 = calc.multiTwoNumber(10, 20);

		System.out.println(result2);
		
	}

}

// 메모리 공간에 할당 non-static