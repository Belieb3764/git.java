package com.greedy.level01.normal;

//import static com.greedy.level01.normal.RandomMaker.rockpaperScissors;
import static com.greedy.level01.normal.RandomMaker.*;

public class Application1 {

	/* 실행용 메소드 */
	public static void main(String[] args) {
		
		/* RamdomMaker 클래스의 메소드를 호출해서 실행 */

		//RandomMaker.rockpaperScissors();
	
		System.out.println(rockpaperScissors());
		
		System.out.println(tossCoin());
	}
}
