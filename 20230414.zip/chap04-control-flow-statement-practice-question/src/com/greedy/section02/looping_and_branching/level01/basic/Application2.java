package com.greedy.section02.looping_and_branching.level01.basic;

public class Application2 {

	public static void main(String[] args) {
		
		/* 10부터 1까지 결과를 출력하세요
		 * 
		 * -- 출력 예시 --
		 * 10 9 8 7 6 5 4 3 2 1
		 * */
		for(int i = 10; i >= 1; i--) { //i=10,9,8,7,6,5,4,3,2,1
			System.out.print(i+" ");
		}
	}
}
