package com.greedy.section01.polymorphism;

public class Application2 {
	
	public static void main(String[] args) {
		
		
		Animal[] animals = new Animal[5]; //객체 배열
//		animals[0] = null값
		
		//다형성 - 원래라면 두개의주소로 해야하는일을 하나의 주소로 할수있게만들어주는것
		animals[0] = new Rabbit();
		animals[1] = new Tiger();
		animals[2] = new Rabbit();
		animals[3] = new Tiger();
		animals[4] = new Rabbit();
		
		for(int i = 0; i < animals.length; i++) {
			animals[i].cry();
		}
	
		for(int i = 0; i < animals.length; i++) {
			
			if(animals[i] instanceof Rabbit) {
				((Rabbit) animals[i]).jump();
			} else if(animals[i] instanceof Tiger) {
				((Tiger) animals[i]).bite();
			} else {
				System.out.println("호랑이나 토끼가 아닙니다.");
			}
 		}
	
	
	}

}
