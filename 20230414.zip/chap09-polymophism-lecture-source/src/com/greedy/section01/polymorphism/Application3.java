package com.greedy.section01.polymorphism;

public class Application3 {
	public static void main(String[] args) {
		
		/* 매개변수에도 다형성을 활용할 수 있다. */
		Application3 app3 = new Application3();
	
		Animal animal1 = new Rabbit();	//Animal
		Animal animal2 = new Tiger();	//Animal
		
		app3.feed(animal1);
		app3.feed(animal2);
	
		Rabbit animal3 = new Rabbit();	// Rabbit
		Tiger animal4 =  new Tiger();	// Tiger 
		
		//위에 파란색 글씨는 그냥 앞에걸 보고 그거라고생각하는게..편할거같음..

		app3.feed((Animal) animal3); //명시적 형변환  //지금 이상태에서 animal3은 Rabbit이기때문에 up-casting이다
		app3.feed((Animal) animal4);
	
		app3.feed(animal3);			// 묵시적 형변환
		app3.feed(animal4);
		
		app3.feed(new Rabbit());	
		app3.feed(new Tiger());
		
		//자동으로 up-casting일어남
		
	}
	
	//여기에는 동적바인딩때문에 각기 다른 값이 들어온다
	/**
	 * <pre>
	 * 동물에게 먹이를 주기 위한 용도의 메소드
	 *</pre>
	 * @param animal
	 */
	public void feed(Animal animal) {
		
		animal.eat();
	}
	
}
