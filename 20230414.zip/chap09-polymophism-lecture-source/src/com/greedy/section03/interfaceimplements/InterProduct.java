package com.greedy.section03.interfaceimplements;

public interface InterProduct extends java.io.Serializable{//(직렬) /*,java.util.Comparator(비교) */ {
	
	/* 인터페이스가 인터페이스를 상속받을 시에는 extends 키워드를 이용하며
	 * 이 때 여러 인터페이스를 다중 상속 받을 수 있다.
	 * */
	
	/* 인터페이스는 상수 필드만 작성가능하다.
	 * 
	 * public static final 제어자 조합을 상수 필드라고 한다.
	 * 반드시 선언과 동시에 초기화 해줘야한다.
	 * */
	
	public static final int MAX_NUM = 100;
	
	/* 상수 필드만 가질 수 있기 때문에 모든 필드는 묵시적으로 public static final이다 */
	int MIN_NUM = 10;
	
	/* 인터페이스는 기본생성자를 가질 수 없다. */
//	public InterProduct() {}
	
	/* 인터페이스는 구현부가 있는 non-static 메소드를 가질 수 없다. */
//	public void nonStaticMethod() {}
	
	/* 추상 메소드만 작성이 가능하다. */
	public abstract void nonStaticMethod(); // protected사용불가 public 생략해서 abstract void ~로 작성은 가능
	
	void abstMethod(); // 일반 메소드처럼 보이지만 public abstract가 생략되어있는것임
	
	/* 추가된 문법 (JDK 1.8 추가된 기능) */
	public static void staticMethod() {
		System.out.println("InterProduct클래스의 staticMethod 호출됨...");
	}

	public default void defaultMethod() {
		System.out.println("InterProduct클래스의 defaultMethod 호출됨...");
	}
	
	

}
