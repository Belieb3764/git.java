package com.greedy.section03.interfaceimplements;

public class Product extends java.lang.Object implements InterProduct, java.io.Serializable {
		/*단일상속 받을거라고 표기*/ 
	
	@Override
	public void nonStaticMethod() {
		
		System.out.println("InterProduct의 nonStaticMethod 오버라이딩한 메소드 호출함...");
	}

	@Override
	public void abstMethod() {
		
		System.out.println("InterProduct의 abstMethod 오버라이딩한 메소드 호출함...");
	}
	
	//위에 두 메소드는 인터페이스의 강제성때문에 오버라이딩된거임...!
	
	/* static 메소드는 오버라이딩 할 수 없다. */
	
	/* default 메소드는 인터페이스에서만 작성 가능하다. */
	
//	public default void defaultMethod() {}
	
	/* default 키워드를 제외하면 오버라이딩 가능하다. */
	@Override
	public void defaultMethod() {
		
		System.out.println("Product 클래스의 defaultMethod 메소드 호출함...");
		
	}
	
	
	
	

}
