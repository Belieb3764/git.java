package com.greedy.section02.abstractclass;

public class SmartPhone extends Product {// 맨처음 product를 상속받게되면 SmartPhone에 빨간줄이 뜨는데
										// 거기에 마우스 올려서 메소드 자동으로 만들어주면 빨간줄 해결

	public SmartPhone() {}
	
	@Override
	public void abstMethod() {

		System.out.println("Product클래스의 abstMethod를 오버라이딩 한 메소드 호출함");
	} 
	
	public void printSmartPhone() {
		
		System.out.println("SmartPhone 클래스의 printSmartPhone 메소드 호출함..");
	}

}
