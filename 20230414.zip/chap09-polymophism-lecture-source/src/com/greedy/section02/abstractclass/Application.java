package com.greedy.section02.abstractclass;

public class Application {
	
	public static void main(String[] args) {
	
	/* 추상클래스와 추상메소드
	 * 
	 * 추상메소드를 0개 이상(없어도됌) 포함하는 클래스를 추상클래스라고한다
	 * 
	 * 추상클래스는 클래스의 선언부에 abstract키워드를 명시해야 한다.
	 * 추상클래스는 인스턴스를 생성할 수 없다.(미완성이기때문에)
	 * 
	 * 추상클래스를 상속받아 구현할 때는 extends 키워드를 사용하며
	 * 자바에서는 extends로 클래스를 상속 받을 시 하나의 부모 클래스만 가질 수 있다.(단일상속)
	 * 
	 * 추상메소드란?
	 * 메소드의 선언부만 있고 구현부가 없는 메소드를 추상 메소드라고한다.
	 * 추상메소드의 경우 반드시 abstract 키워드를 메소드 헤드에 작성해야 한다.
	 * 예)public abstract void method(); <-세미콜론으로 끝맺음
	 * */
	
//   Product product = new Product(); // 추상클래스는 인스턴스 생성 불가
		
	 SmartPhone smartPhone = new SmartPhone(); // SmartPhone타입, Product타입
	 System.out.println(smartPhone instanceof SmartPhone);
	 System.out.println(smartPhone instanceof Product);
	 
	 /* 따라서 다형성을 적용해서 추상클래스를 레퍼런스 타입으로 활용할 수 있다.*/
	 Product product = new SmartPhone();
	 
	 product.abstMethod(); // 동적바인딩
	 
	 product.nonStaticMethod(); // 얘도 사용가능함 product만 접근할수있음
	 
	 Product.staticMethod();

	
	/* 추상클래스를 왜 쓰는가
	 * 추상클래스의 추상메소드는 오버라이딩에 대한 강제성이 부여된다.
	 * 따라서 여러 클래스들을 그룹화하여
	 * 필수 기능을 정의하여 강제성을 부여 해 개발 시 일관된 인터페이스(틀)를 제공할 수 있다.
	 * */
	}
}