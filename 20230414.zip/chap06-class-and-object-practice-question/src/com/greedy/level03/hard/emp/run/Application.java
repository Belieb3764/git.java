package com.greedy.level03.hard.emp.run;


import java.util.Scanner;

import com.greedy.level03.hard.emp.model.dto.EmployeeDTO;

public class Application {
	
	public static void main(String[] args) {
		
		EmployeeDTO emp1 = new EmployeeDTO(); 	
//		System.out.println(emp1.getInformation());
		
		Scanner sc = new Scanner(System.in);
		
		int number = sc.nextInt();
		sc.nextLine(); // nextLine으로 넘어갈때 엔터가 넘어가서 먹어줘야하므로 sc.nextLine();으로 처리해준다
		String name = sc.nextLine();
		String dept = sc.nextLine();
		String job = sc.nextLine();
		int age = sc.nextInt();
		char gender = sc.next().charAt(0);
		int salary = sc.nextInt();
		double bonuspoint = sc.nextDouble();
		sc.nextLine();
		String phone = sc.nextLine();
		String address = sc.nextLine(); 
	

		
//		EmployeeDTO emp2 = new EmployeeDTO();
		System.out.println(number);
		System.out.println(name);
		System.out.println(dept);
		System.out.println(job);
		System.out.println(age);
		System.out.println(gender);
		System.out.println(salary);
		System.out.println(bonuspoint);
		System.out.println(phone);
		System.out.println(address);
//		
		
		
	}
}

//		System.out.print("직원의 번호를 입력하세요 : ");
//		int numeber = sc.nextInt();
//		System.out.print("직원의 이름를 입력하세요 : ");
//		String name = sc.nextLine();
//		System.out.print("직원의 부서를 입력하세요 : ");
//		String dept = sc.nextLine();
//		System.out.print("직원의 직급를 입력하세요 : ");
//		String job = sc.nextLine();
//		System.out.print("직원의 나이를 입력하세요 : ");
//		int age = sc.nextInt();
//		System.out.print("직원의 성별를 입력하세요 : ");
//		char gender = sc.next().charAt(0);
//		System.out.print("직원의 보너스를 입력하세요 : ");
//		double saraly = sc.nextDouble();
//		System.out.print("직원의 핸드폰번호를 입력하세요 : ");
//		String phone = sc.nextLine();
//		System.out.print("직원의 주소를 입력하세요 : ");
//		String address = sc.nextLine();


//		emp1.setNumber(200);
//		emp1.setName("홍길동");
//		emp1.setDept("영업부");
//		emp1.setJob("과장");
//		emp1.setAge(20);
//		emp1.setGender('남');
//		emp1.setSalary(2000000);
//		emp1.setBonusPoint(0.5);
//		emp1.setPhone("010-1234-5678");
//		emp1.setAddress("서울시 서초구 서초동");
//		
//		
//		EmployeeDTO emp2 = new EmployeeDTO();
//		System.out.println(emp1.getNumber());
//		System.out.println(emp1.getName());
//		System.out.println(emp1.getDept());
//		System.out.println(emp1.getJob());
//		System.out.println(emp1.getAge());
//		System.out.println(emp1.getGender());
//		System.out.println(emp1.getSalary());
//		System.out.println(emp1.getBonusPoint());
//		System.out.println(emp1.getPhone());
//		System.out.println(emp1.getAddress());