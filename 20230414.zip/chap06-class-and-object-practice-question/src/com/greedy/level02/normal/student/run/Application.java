package com.greedy.level02.normal.student.run;

import java.util.Scanner;

import com.greedy.level02.normal.student.model.vo.StudentVO;

public class Application {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int grade = sc.nextInt();
		int classroom = sc.nextInt();
		sc.nextLine(); // sc.nextLine();때문에 스페이스바..?를 한번먹어줘야함
		String name = sc.nextLine();
		double height = sc.nextDouble();
		char gender = sc.next().charAt(0);
		
		StudentVO stu = new StudentVO();
		
//		stu.setGrade(grade);
//		stu.setClassroom(classroom);
//		stu.setName(name);
//		stu.getHeight();
//		stu.getGender();
		
		System.out.println("학년 : " + grade);
		System.out.println("반 : " + classroom);
		System.out.println("이름 : " + name);
		System.out.println("키 : " + height);
		System.out.println("성별 : " + gender);
		
	}
}
