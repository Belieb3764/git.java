package com.jar.test;

public class TestClass {
	
	public static void main(String[] args) {
		System.out.println("나는 마스터다");
		System.out.println("냥이");
	}

}
