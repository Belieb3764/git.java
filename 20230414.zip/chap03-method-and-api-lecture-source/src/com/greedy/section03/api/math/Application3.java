package com.greedy.section03.api.math;

import java.util.Random;

public class Application3 {

	public static void main(String[] args) {
		
		
		/* java.util.Random 클래스
		 * java.util.Random 클래스의 nextInt() 메소를 이용한 난수 발생
		 * */

		/* 원하는 범위의 난수를 구하는 공식
		 * random.nextInt(구하려는 난수의 갯수) +  구하려는 난수의 최솟값
		 * */
		
		Random random  = new Random();  //객체
			//Random클래스의 생선된 주소값을 담고,
		
		/* 0부터 9까지 난수 발생 */
		int randomNumber1 = random.nextInt(10);
		System.out.println("0부터 9까지의 난수 : " + randomNumber1);
		
		/* 1부터 10까지의 난수 발생 */
		int randomNumber2 = random.nextInt(10) + 1;
		System.out.println("1부터 10까지의 난수 : " + randomNumber2);
		
		
		/* 20부터 45까지의 난수 발생 */
		int randomNumber3 = random.nextInt(26);
		System.out.println("20부터 45까지의 난수 : " + randomNumber3);
		
		/* -128부터 127까지의 난수 발생 */
//		int randomNumber4 = random.nextInt(256) - 128;
		int randomNumber4 = new Random().nextInt(256) - 128;
		System.out.println("-128부터 127까지의 난수 : " + randomNumber4);
		
		// randomNuber4안에는 발생한 난수의 값포함 
		
	
	}

}
