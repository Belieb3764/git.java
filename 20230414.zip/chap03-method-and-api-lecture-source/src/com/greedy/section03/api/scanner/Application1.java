package com.greedy.section03.api.scanner;

import java.util.Scanner;

public class Application1 {

	public static void main(String[] args) {
		
		
		/* 콘솔 화면에 값을 입력 받아 출력해보기*/
		
		/* 1. Scanner 객체 생성 */
		/* 1-1. 원래 이렇게 Scanner 객체를 생성해야한다. */
//		java.util.Scanner sc = new java.util.Scanner(java.lang.System.in);

		/* 1-2. 다른 패키지에 있는 클래스 사용 시 패키지명 생략하기 위해서 import구문을 추가*/
		//input 컴퓨터에 입력할때
		Scanner sc = new Scanner(System.in); //사용자가 키보드를 이용하여 값을 입력하면 값을 받은 기능을
													   // 실행하기 위해서 객체를 생성했다.
		
		/* 2. 자료형별 값 입력받기 */
		
		/* 2-1. 문자열 입력받기*/
		/* nextLine() :  입력받은 값을 문자열로 반환해준다. */
		System.out.print("이름을 입력하세요 : ");
		String name = sc.nextLine();
		System.out.println("입력하신 이름은 " + name + "입니다.");
		
		
		/* 2-2. 정수형 값 입력 받기 */
		/* nextInt() : 입력받은 값을 int형으로 반환한다.
		 * */
	
		System.out.print("나이를 입력하세요 : ");
		int age = sc.nextInt();
		System.out.println("입력하신 나이는 " + age + "입니다.");
		
		
		/* nextLong() : 입력받은 값을 long형으로 반환한다.
		 * */
		System.out.print("금액을 입력해주세요 : ");
		long money = sc.nextLong();
		System.out.println("입력하신 금액은 " + money + "원 입니다.");
	
		/* 2-3. 실수형 값 입력받기 */
		/* nextFloat() :  입력받은 값을 float형으로 반환한다.
		 * 정수 형태로 입력받으면 실수로 변환 후 정상 동작
		 * 소수점 6자리에서 올림처리
		 * */
		System.out.print("키를 입력해 주세요 : ");
		float height = sc.nextFloat();
		System.out.println("입력하신 키는 " + height  + "cm 입니다.");
		
		/* nextDouble() : 입력받은 값을 double형으로 반환한다.
		 * 정수 형태로 입력받으면 실수로 변환 후 정상 동작
		 * 소수점 16자리에서 올림처리
		 * */
		System.out.print("원하는 실수를 입력하세요 : ");
		double number =  sc.nextDouble();
		System.out.println("입력하신 실수는 " + number + "입니다.");
		
		
		/* 2-4. 논리형 값 입력받기*/
		/* nextBoolean  : 입력받은 값을 boolean형으로 반환
		 * true or false 외에 다른 값을 입력하게 되면 InputMismatchException발생
		 * */
		System.out.println("참과 거짓 중에 한 가지를 true or flase로 입력해주세요 : ");
		boolean isTrue = sc.nextBoolean();
		System.out.println("입력하신 논리 값은 " + isTrue + "입니다.");
	
		/* 2-5. 문자형 값 입력받기 */
		/* 아쉽게도 문자를 직접 입력 받는 기능을 제공하지는 않는다.
		 * 따라서 문자열로 입력을 받고, 입력받은 문자에서 원하는 순번째 문자를 분리해서 사용해야한다.
		 * 
		 * java.lang.String에서 charAt(int index)를 사용한다.
		 * index를 정수형으로 입력하면 문자열에서 해당 인덱스에 있는 한 문자를 문자형으로 반환해주는 기능
		 * 
		 * index는 0부터 시작하는 숫자체계이며 컴퓨터에서 주로 사용하는 방식
		 * -> 만약 존재하지 않는 인덱스를 입력하게되면 IndexOutOfBoundsException이 발생한다.
		 * */
	
		
		// Scanner를 이용해서 안녕하세요라고하는 문자열을 입력 했다고 가정
		// 	"안녕하세요" - > 안 녕 하 세 요
	    //					0 1  2  3  4
		// 문자열 갯수 =5 index갯수 = 4  
	
		sc.nextLine(); // <-- 요기에 추가하는 이유는 뒤에서 추가 설명
		System.out.println("아무 문자나 입력 해주세요 : ");
		char ch = sc.nextLine().charAt(0);
		System.out.println("입력하신 문자는 " + ch + "입니다.");
	
		sc.close();
		
		
		// 중요!!
		// 스캐너(Scanner) - >사용자가 입력한 값을 받아올수있다.
		
		/* 
		 * 문자열 next(), nextLine() 
		 * 
		 * 숫자 
		 * 		정수	nextByte(), nextShort(), nextInt(), nextLong()
		 * 		실수	nextFloat(), nextDouble()
		 * 
		 * 논리 nextBoolean()
		 * 
		 * 문자 제공되는 메소드가 없어서
		 * 		next() 또는 nextLine()메소드로 문자열을 입력받고
		 * 		그러면 입력받은 문자열이 String클래스에서 제공하는
		 * 		메소드(charAt(int index))를 이용해서 원하는 문자를
		 * 		뽑아내서 사용할 수 있다. 
		 * */
	}

}
