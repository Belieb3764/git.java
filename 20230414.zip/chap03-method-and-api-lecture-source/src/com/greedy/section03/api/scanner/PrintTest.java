package com.greedy.section03.api.scanner;

public class PrintTest {

	public static void main(String[] args) {
		
		
		/* 출력을 하기위해서 사용하는 메소드
		 * System.out.print()
		 * System.out.println()
		 */
	
		System.out.println("안녕");
		System.out.println("반가워");
		System.out.println(" ");
		System.out.println("그래");
		System.out.println("안녕");
	
	}

}
