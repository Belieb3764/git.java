package com.greedy.section02.package_and_import;
/* 사용하려는 클래스까지를 작성 */
import com.greedy.section01.method.Calculator;
//import com.greedy.section01.method.*; // 모든 클래스를 다 사용하겠다는 뜻 

/* static improt의 경우 사용하려는 static method까지 전부 써줘야한다.*/
import static com.greedy.section01.method.Calculator.maxNumberOf;
//import static com.greedy.section01.method.Calculator.*;
import java.sql.Date;

public class Application2 {

	public static void main(String[] args) {
		
		/* 임포트 : 서로 다른패키지에 존재하는 클래스를 사용하는 경우 패키지명을 풀 클래스 이름을 
		 * 		   사용해야한다. 하지만 매번 다른 클래스의 패키지명까지 기술하기에는 번거롭다.
		 * 		   그래서 패키지명을 생략하고 사용할 수 있도록 한 구문이 import 구문이다.
		 * 		   import는 package 선언문과 class선언문 사이에 작성하며
		 * 		   어떠한 패키지 내에 있는 클래스를 사용할 것인지에 대해 미리 선언하는 효과를 가진다.
		 * 
		 *    
		 *         동일한 클래스명을 import하는 경우는 패키지가 달라고 허용하지 않고
		 *         둘 중 하나만 사용할 수 있으며, 다른 클래스를 사용할려면 풀 패키지명을 붙여서
		 *         사용한다.         
		 * /
		
		// ctrl + shift + o : import 자동 추가
		/* non-static일 경우 */
		Calculator calc = new Calculator();
		int min = calc.minNumberOf(50, 60);
		
		System.out.println("50과 60중 더 작은 값은 :" + min);
		
		/* static일 메소드일 경우 */
		int max = Calculator.maxNumberOf(50, 60);
		System.out.println("50과 60중 더 큰 값은 : " + max);
		
		int max2 = maxNumberOf(100, 200);
		 System.out.println("100과 200 중 더 큰 값은 : " + max);
		
		 // Date 클래스 -> java.util.Date, java.sql.Date
		 
		 Date date = new Date(System.currentTimeMillis());
		 java.util.Date utilDate = new java.util.Date(System.currentTimeMillis());
		 
	}

}
