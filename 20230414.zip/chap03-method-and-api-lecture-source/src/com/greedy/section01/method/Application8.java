package com.greedy.section01.method;

public class Application8 {

	public static void main(String[] args) {
		
		/* static 메소드 호출 
		 * static 있는 메소드나 non-static 메소드 둘다 메소드의 동작 흐름은 동일하다.
		 * */
		/* non=static 메소드를 호출할떄
		 * 클래스명 사용할이름  = new 클래스명();
		 * 사용할이름.메소드명();
		 * 
		 * static메소드를 호출할때
		 * 클래스명.메소드명();
		 * */
		System.out.println("10과 20의 합 : " + Application8.sumTwoNumbers(10, 20));
	
		/* 동일한 클래스 내에 작성된 static 메소드는 클래스명 생략이 가능하다. */
		System.out.println("10과 20의 합 : " + sumTwoNumbers(10, 20));
	
	}													// 이태리체처럼 기울어진 글자는 static이 붙어있다고 생각하면됨

	public static int sumTwoNumbers(int first, int second) {
		
		return first + second;
	}
}
