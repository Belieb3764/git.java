package com.greedy.section01.method;

public class Calculator {

	public int minNumberOf(int first, int second) {
		
		/* 두 수가 동일한 조건은 제외하고
		 * 두 수를 비교하여 첫 번째 숫자가 크면 두 번째 숫자를 반환하고,
		 * 아니면 첫번째 숫자를 반환하도록 작성
		 * */
		return (first > second)? second: first;
	}
	
	public static int maxNumberOf(int first, int second) {
	
		return (first > second)? first : second;
	}
	
}
