package com.greedy.section02.extend;

public class Rabbit extends Mammal {
	
	public void cry() {
		
		System.out.println("토끼가 울음소리를 냅니다. 끾끾!");
	}
}
