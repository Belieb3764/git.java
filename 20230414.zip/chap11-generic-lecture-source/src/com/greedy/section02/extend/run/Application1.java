package com.greedy.section02.extend.run;

import com.greedy.section02.extend.Bunny;
import com.greedy.section02.extend.DrunkenBunny;
import com.greedy.section02.extend.Rabbit;
import com.greedy.section02.extend.RabbitFarm;

public class Application1 {
	
	public static void main(String[] args) {
		
		/* public class RabbitFram<T extends Rabbit>일 경우 */
		/* Animal 타입으로는 제네릭 클래스 인스턴스 생성이 불가능 */
//		RabbitFarm<Animal> farm1 = new RabbitFarm<>();
	
		/* Mammal 타입으로는 제네릭 클래스 인스턴스 생성이 불가능 */
//		RabbitFarm<Mammal> farm1 = new RabbitFarm<>();
	
		/* 전혀 다른 타입으로는 제네릭 클래스 인스턴스 생성이 불가능 */
//		RabbitFarm<Snake> farm1 = new RabbitFarm<>();
		
		// <T extends Rabbit>일 경우 Rabbit타입이나 Rabbit의 후손으로는 인스턴스 생성이 가능하다.
		RabbitFarm<Rabbit> farm4 =  new RabbitFarm<>();
//		RabbitFarm<Rabbit, Rebtile> farm4 =  new RabbitFarm<>();
		RabbitFarm<Bunny> farm5 =  new RabbitFarm<>();
		RabbitFarm<DrunkenBunny> farm6 =  new RabbitFarm<>();
		
		farm4.setAnimal(new Rabbit());
		farm4.getAnimal().cry();
		
		farm5.setAnimal(new Bunny());
		farm4.getAnimal().cry();
		
		farm6.setAnimal(new DrunkenBunny());
		farm6.getAnimal().cry();
	}
}
