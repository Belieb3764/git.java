package com.greedy.section02.extend.run;

import com.greedy.section02.extend.Bunny;
import com.greedy.section02.extend.DrunkenBunny;
import com.greedy.section02.extend.Rabbit;
import com.greedy.section02.extend.RabbitFarm;
import com.greedy.section02.extend.WildCardFarm;

public class Application2 {
	
	public static void main(String[] args) {
		
		/* 와일드카드(WildCard)
		 * 제네릭 클래스 타입의 객체를 메소드의 매개변수로 받을 때, 그 객체의 타입변수를 제한할 수 있다.
		 * 
		 * <?> : 제한없음
		 * <? extends Type> : 와일드카드의 상한 제한(Type과 Type의 후손을 이용해 생성한 인스턴스만 인자로 사용가능)
		 * <? super Type> : 와일드카드의 하한 제한(Type과 Type의 부모를 이용해 생성한 인스턴스만 인자로 사용가능)
		 * */

	
		WildCardFarm wildCardFarm  = new WildCardFarm(); //인스턴스 생성
		
		/* 매개변수의 타입 제한이 없는 경우 */
		/* 농장 생성 자체가 불가능한 것은 매개변수로 사용할 수 없다. */
//		wildCardFarm.anyType(new RabbitFarm<Mammal>(new Mammal())); // 생성은 되지만 오류발생
//		wildCardFarm.anyType((new RabbitFarm<Reptile>(new Reptile)); //생성 아예안됌
	
//		new RabbitFarm<Rabbit>(); //기본생성자이면서 제네릭추가
//		new RabbitFarm<Rabbit>(new Rabbit()); // 매개변수있는 생성자이면서 제네릭 추가
	
		
		wildCardFarm.anyType(new RabbitFarm<Rabbit>(new Rabbit()));
		wildCardFarm.anyType(new RabbitFarm<Bunny>(new Bunny()));
		wildCardFarm.anyType(new RabbitFarm<DrunkenBunny>(new DrunkenBunny()));
		
		
		/* Bunny이거나 Bunny의 후손 토끼농장만 매개변수로 사용이 가능하고
		 * 상위타입으로 만든 토끼농장은 매개변수로 사용이 불가능하다.
		 * */
		
		/* 시작을 상위타입으로 줬기때문에 안됌*/
//		wildCardFarm.extendsType(new RabbitFarm<Rabbit>(new Rabbit()));
		wildCardFarm.extendsType(new RabbitFarm<Bunny>(new Bunny()));
		wildCardFarm.extendsType(new RabbitFarm<DrunkenBunny>(new DrunkenBunny()));
	
		/* Bunny이거나 Bunny의 상위 타입 토끼 농장만 매개변수로 사용이 가능하고
		 * 하위타입으로 만든 토끼 농장은 매개변수로 사용이 불가능하다.
		 */
											//Rabbit삭제해도 작동가능
		wildCardFarm.superType(new RabbitFarm<Rabbit>(new Rabbit()));
		wildCardFarm.superType(new RabbitFarm<Bunny>(new Bunny()));
//		wildCardFarm.superType(new RabbitFarm<DrunkenBunny>(new DrunkenBunny()));
		
	
	}

}
