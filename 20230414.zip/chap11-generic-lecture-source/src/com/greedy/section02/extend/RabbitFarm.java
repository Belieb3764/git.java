package com.greedy.section02.extend;

//public class RabbitFarm<T> {
/* 인터페이스 상속 시 implements 키워드 대신 extends를 사용한다. */
//public class RabbitFarm<T implements Animal> {  
//public class RabbitFarm<T extends Animal> {  

/* 클래스 상속 시 extends 사용 */
public class RabbitFarm<T extends Rabbit> {

/* Reptile 자체를 타입변수로 본다.*/
//public class RabbitFarm<T extends Rabbit, Reptile> { //두개의 타입이 같이있어야 완전한 애로 본다는거 원래는 하나의 타입만 봄
								//[하나의 타입 변수]
	
	private T animal;
	
	public RabbitFarm() {}
	
	public RabbitFarm(T animal) {
		this.animal = animal;
	}

	public T getAnimal() {
		return animal;
	}

	public void setAnimal(T animal) {
		this.animal = animal;
	}
	
}
