package com.greedy.section02.extend;

public class Reptile implements Animal {

}
