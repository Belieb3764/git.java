package com.greedy.section01.init;

public class Application {
	
	public static void main(String[] args) {
		
		/* 객체배열은 레퍼런스변수에 대한 배열이다.
		 * 생성한 인스턴스도 배열을 이용해서 관리하면
		 * 동일한 타입의 여러 개 인스턴스를 각각 취급하지 않고 연속 처리할 수 있어서 유용하다.
		 * 
		 * 또한 반환값은 1개의 값만 반환할 수 있기 때문에
		 * 동일한 타입의 여러 인스턴스를 반환해야하는 경우 객체배열을 이용할 수 있다.
		 * */
		Car car1 = new Car("페라리", 300);
		Car car2 = new Car("람보르기니", 350);
		Car car3 = new Car("롤스로이스", 250);
		Car car4 = new Car("부가티베이론", 400);
		Car car5 = new Car("포터", 500);
	
	
		car1.driveMaxSpeed();
		car2.driveMaxSpeed();
		car3.driveMaxSpeed();
		car4.driveMaxSpeed();
		car5.driveMaxSpeed();
		
		/* 동일한 타입의 인스턴스를 여러 개 사용해야 할 때 객체배열을 이용하면 보다 효율적으로 사용이 가능하다. */
		Car[] carArray = new Car[5]; 	// int iarr = new int[5] 
		
		// 1차원 배열이여서 초기값이 0처럼 보이지만 객체배열이기때문에 초기값은 null이다 반드시 기억해야함
		
		// 각 인덱스에는 기본값 null로 초기화 되어 있어서 인덱스별로 인스턴스를 생성해야한다.
//		System.out.println(carArray[0]);
//		carArray[0].driveMaxSpeed();
		
		carArray[0] = new Car("페라리", 300);
		carArray[1] = new Car("람보르기니", 350);
		carArray[2] = new Car("롤스로이스", 250);
		carArray[3] = new Car("부가티베이론", 400);
		carArray[4] = new Car("포타", 500);
		
		//객체 '배열'이라서 반복문 사용가능
		for(int i = 0; i < carArray.length; i++) {
			carArray[i].driveMaxSpeed();
		}
		
		Car[] carArray2 = {
				new Car("페라리", 300)     
			   , new Car("람보르기니", 350)   
               , new Car("롤스로이스", 250)   
		       , new Car("부가티베이론", 400)  
	           , new Car("포타", 500)      
		};
		
		/* 향상된 for문도 사용이 가능하다. */
		for(Car c : carArray2) {
			c.driveMaxSpeed();
		}
	}
}		
