package com.greedy.section02.uses;

/**
 * <pre>
 * 회원 관리 기능을 제공하는 용도의 클래스
 * </pre>
 */
public class MemberManager {
	
	/**
	 * <pre>
	 * 여러 명의 회원 정보를 등록
	 * </pre>
	 */
	public void signUpMembers() {
		
		/* 5명의 회원 정보를 담을 객체 배열 생성 */
		MemberDTO[] members = new MemberDTO[5]; // 현재 각 인덱스에는 null로 초기화 되어있다
	
	
		/* 5명의 회원 정보를 각 인덱스에 할당 */
		members[0] = new MemberDTO(1, "user01", "pass01", "홍길동", 20, '남');
		members[1] = new MemberDTO(2, "user02", "pass02", "유관순", 16, '여');
		members[2] = new MemberDTO(3, "user03", "pass03", "이순신", 49, '남');
		members[3] = new MemberDTO(4, "user04", "pass04", "신사임당", 36, '여');
		members[4] = new MemberDTO(5, "user05", "pass05", "윤봉길", 22, '남');
	
		MemberInsertManager memberInsertManager = new MemberInsertManager();
		memberInsertManager.insert(members); //(members)여러개의 객체배열을 담은 주소값
		
		//memberInsertManager클래스를 생성한 후 참조하기위해 
		//MemberInsertManager memberInsertManager = new MemberInsertManager();생성자를 선언하고 
		//memberInsertManager.insert(members);참조한것이다
		
		// 1 - 여기서 생성되어있는 값(회원정보)을 객체배열에 집어넣겠다
	
	}
	
	
	/**
	 * <pre>
	 * 모든 회원 목록을 조회하여 정보를 출력
	 * </pre>
	 */
	public void printAllMembers() {
		            //5 - 값은 똑같은데 주소값은 다름
//		MemberDTO[] selectedMembers = new MemberSelectManager().selectAllMembers();
		// 위의 식을 아래와 같이 풀 수 있다.
		MemberSelectManager memberSelectManager = new MemberSelectManager();
		MemberDTO[] selectedMembers = memberSelectManager.selectAllMembers();
		// (얕은복사) memberSelectManager에있는 selectAllMembers();객체배열을 
		// selectedMembers에 저장하는것(return받은것)이고 MemberDTO[]지정해준 이유는 
		// memberSelectManager가 MemberDTO[]배열이기때문에
		 //2- selectAllMembers 정보값을 조회해서 가져왔다고 가정 
		
		System.out.println("----------------- 가입된 회원 목록 -----------------");
		for(MemberDTO member  :  selectedMembers) { //향상된 for문
			System.out.println(member.getInfomation());
		}
		
		System.out.println("--------------------------------------------------");
		System.out.println("총" + selectedMembers.length + "명의 회원이 가입되어 있습니다.");
	
	}
	
}
