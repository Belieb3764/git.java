package com.greedy.section02.uses;

import java.util.Scanner;

public class Application {
	
	public static void main(String[] args) {
		
		/* DTO를 활용한 간단한 회원 관리용 프로그램 
		 * 
		 * 구현기능
		 * 1. 여러 명의 회원 정보를 받아 한 번에 여러 회원 정보를 등록
		 * 2. 전체 회원 조회 시 여러 명의 회원 정보를 반환
		 * */
		
		Scanner sc = new Scanner(System.in);
		
		MemberManager memberManager = new MemberManager();
		
		menu: //while문에 이름표 붙여준것이라고 생각하면됌 앞에 메뉴는 명명을 바꿔도 상관없음
		while(true) { //조건식...^^
			System.out.println("=========== 회원 관리 프로그램 ===========");
			System.out.println("1. 회원 등록");
			System.out.println("2. 회원 전체 조회");
			System.out.println("9. 프로그램 종료");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
			
			switch(no) { // switch case 비교 : 비교하고 실행하는 것
				case 1 : memberManager.signUpMembers(); break;
				case 2 : memberManager.printAllMembers(); break;
				case 9 : System.out.println("프로그램을 종료합니다."); break menu;
				default : System.out.println("잘못된 번호를 입력하셨습니다."); break;
				//break가 없으면 1~9번까지 다돌기때문에 break를 걸어서 반복문탈출
				//default를 적어도 break로 switch를 빠져나감
			}
		}
	}

}
