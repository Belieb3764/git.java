package com.greedy.section01.array.level03.hard;

import java.util.Scanner;

public class Application1 {

	public static void main(String[] args) {
		
		/* 홀수인 양의 정수를 입력 받아 입력 받은 크기 만큼의 정수형 배열을 할당하고 
		 * 배열의 중간까지는 1부터 1씩 증가하여 오름차순으로 값을 넣고,
		 * 중간 이후부터 끝까지는 1씩 감소하여 내림차순으로 값 넣어 출력하세요
		 * 
		 * 단, 홀수인 양의 정수를 입력하지 않은 경우에는 "양수 혹은 홀수만 입력해야 합니다."를 출력하세요
		 * 
		 * -- 입력 예시 --
		 * 홀수인 양의 정수를 입력하세요 : 7
		 * 
		 * -- 출력 예시 --
		 * 1 2 3 4 3 2 1
		 * 
		 * -- 입력 예시 --
		 * 홀수인 양의 정수를 입력하세요 : 8
		 * 
		 * -- 출력 예시 --
		 * 양수 혹은 홀수만 입력해야 합니다.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("홀수인 양의 정수를 입력하세요 : ");
		int num = sc.nextInt(); // 정수를 입력받음
		
		if(num % 2 == 1 ) {  //홀수를 구하기위한 조건식
				int iarr[] = new int[num]; //입력받은 크기만큼 배열할당
				int mid = (int)(num / 2 + 1); //중간값을 구하는 변수선언
				int cnt = 0; // 반복문을 해주기위해 cnt변수선언 후 초기화
				
				for(int i = 0; i < mid; i++) { //중간까지 1부터 1씩 증가하며 오름차순
						iarr[i] = ++cnt;
				}
				
				for(int i =mid; i < iarr.length; i++) { // 중간 이후부터 끝까지 1씩감소하면서 내림차순
					iarr[i] = --cnt;
					
				}
		
				for(int i = 0; i < iarr.length; i++) {  //배열출력을 하기위한 for문
					System.out.println(iarr[i] + " ");
					
				}
		} else { //if문이 성립되지않으면 else문을 실행하는것
				System.out.println("양수 혹은 홀수만 입력해야 합니다.");
		}
		sc.close();
	}

}
