package com.greedy.section06.singleton;

public class LazySingleton {
	
	/* 클래스가 초기화 되는 시점에서는 정적 필드를 선언해두고 null로 초기화된다. */
	private static LazySingleton lazy;	// 클래스명이라 기본값 null
	
	/* 싱글톤 패턴은 생성자 호출을 통해 외부에서 인스턴스를 생성하는 것을 제한한다. */
	private LazySingleton() {}
	
	
	public static LazySingleton getInstance() {
		
		if(lazy == null) {
			
			lazy = new LazySingleton(); // 다른곳에서는 new 생성을 아예막음
		}
		
		return lazy;
	}
}

// LazySingleton 은 인스턴스를 나중에 생성한 식