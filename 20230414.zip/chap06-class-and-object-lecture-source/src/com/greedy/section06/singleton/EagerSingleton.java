package com.greedy.section06.singleton;

public class EagerSingleton {

	/* 클래스가 초기화 되는 시점에서 인스턴스를 생성한다. */
	private static EagerSingleton eager = new EagerSingleton();
	  		//static변수
	//final을 붙여서 사용가능함
	
	/* 싱글톤 패턴은 생성자 호출을 통해 외부에서 인스턴스를 생성하는 것을 제한한다. */
	private EagerSingleton() {}

	public static EagerSingleton getInstance() {
		//생성자를 private로 만들어놓고 외부에서 접근을 못하게하고 메모리공간(heap)에 올리고싶으면
		// new EagerSingleton();을 요청하고싶어서 static을 붙여주어 클래스명.get인스턴스 생성해서 값을 가져올수있음
		return eager;
		
		
		
//		private  EagerSingleton eager = new EagerSingleton(); <-1. 여기에서 static을 빼고
//
//		private EagerSingleton() {}
//
//		public static EagerSingleton getInstance() {
//			return new EagerSingleton(); 					<-2. 이렇게 작성하면 singleton이 아님 
			
		// 즉 singleton과 private로 막힌 생성자를 모두 만족시키려면 맨위의 식대로 작성해야함 
	}

}

// EagerSingleton 은 인스턴스를 먼저 생성한 식