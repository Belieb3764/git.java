package com.greedy.section07.kindsofvariable;

public class KindOfVariable { // 클래스영역의 시작
		
	/* 클래스 영역에 작성하는 변수를 필드라고 한다.
	 * 필드 == 멤버변수 멤버(클래스가 가지는 멤버(변수,메소드)라는의미) == 전역변수(클래스 전역에서 사용할 수 있는 변수라는 의미)
	 * */ 

	/* non-static field를 인스턴스 변수라고 한다.(인스턴스 생성 시점에 사용 가능한 변수라는 의미)*/
	private int globalNum;
	
	/* static field를 정적필드(클래스변수)라고한다. (정적(클래스) 영역에 생성되는 변수라는 의미)*/
	private static int staticNum;
	
	//자바에서는 브레스 열면 하나의 영역으로 보면됨
	public void testMethod(int num) { // 메소드 영역의 시작
		
		/* 메소드 영역에서 작성하는 변수를 지역변수라고 한다.
		 * 메소드 괄호 안에 선언하는 변수를 매개변수라고 한다.
		 * 매개변수도 일종의 지역변수로 생각하면된다.
		 * 지역변수와 매개변수 모두 메소드 호출 시 stack을 할당받아 stack에 생성된다.
		 * */
		int localNum;
		
		System.out.println(num); // 매개변수를 호출 시 값이 넘어와서 변경되기 때문에 초기화가 필요 없다.

		/* 지역변수는 선언 외에 다시 사용하기 위해서는 반드시 초기화가 되어야 한다.*/
		localNum = 0; // 이처럼 초기값을 설정해주면 사용가능
		System.out.println(localNum);  // 이것만 단독으로 사용못하고 위에 localNum= 0;으로 초기화 해줘야지 사용가능
										//봤는데 모르겠으면 localNum = 0;이거 주석처리해보면 알수있음..
		System.out.println(globalNum);
		System.out.println(staticNum); // static 내에 있으니까 참조해서 사용가능 
		
	} // 메소드영역의 끝
	
	public void testMethod2() {
		
//		System.out.println(localNum); // 지역변수는 해당 지역(블럭 내)에서만 사용 가능하다.
		System.out.println(globalNum); // 전역변수는 다른 메소드에서도 사용 가능하다.
		System.out.println(staticNum);
	}
	
} // 클래스영역 끝
