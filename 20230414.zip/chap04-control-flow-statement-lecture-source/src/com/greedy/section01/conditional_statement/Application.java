package com.greedy.section01.conditional_statement;

public class Application {

	public static void main(String[] args) {
	
		A_if aif = new A_if();
		//aif.testSimpleIfStatement();
		//aif.testNestedIfStatement();
		
		B_ifElse bie = new B_ifElse();
//		bie.testSimpleIfElseStatement();
//		bie.testNestedIfElseStatemnet();
		
		C_ifElseIf cif = new C_ifElseIf();
//		cif.testSimpleIfElseIfStatement();
//		cif.testNestedIfElseIfStatement();
		
		D_switch dswitch = new D_switch();
//		dswitch.testSimpleSwitschStatement();
		dswitch.testSwitchVendingMachine();

	}

}
