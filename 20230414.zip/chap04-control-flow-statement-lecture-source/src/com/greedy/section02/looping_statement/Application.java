package com.greedy.section02.looping_statement;

public class Application {
	
	public static void main(String[] args) {
		
		A_for af = new A_for();
//		af.testSimpleForStatement();
//		af.testForExample1();
//		af.testForExmple2();
//		af.testForExmple3();
//		af.testForExample4();
//		af.printSimpleGugudan();
		
		A_nestedFor ans = new A_nestedFor();
//		ans.printGugudanFromTwoTonine();
//		ans.printStarInputRowTimes();
//		ans.printTraingleStars();
		
		B_while bwhile = new B_while();
//		bwhile.testSimpleWhileStatement();
//		bwhile.testWhileExmple1();
//		bwhile.testWhileExample2();
//		bwhile.testWhileExample3();
		
		
		C_doWhile cdo = new C_doWhile();
//		cdo.testSimpleDoWhileStatement();
		cdo.testDoWhileExample1();
	
	}

}
