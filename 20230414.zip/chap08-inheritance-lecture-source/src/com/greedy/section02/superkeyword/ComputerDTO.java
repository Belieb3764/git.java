package com.greedy.section02.superkeyword;

import java.util.Date;

public class ComputerDTO extends ProductDTO {
	
	/* ComputerDTO 클래스는 하나의 상품이다. (IS-A) */
	private String cpu;
	private int hdd;
	private int ram;
	private String operationSystem;
	
	
	
	
	/* 기본생성자 */ 
	public ComputerDTO() {
	
		System.out.println("ComputerDTO 클래스의 기본생성자 호출함");
	}
	
	/* 부모 기본생성자를 호출하고 나머지 자식클래스의 필드를 초기화함 */
	public ComputerDTO(String cpu, int hdd, int ram, String operationSystem) {
		super(); // 부모클래스의 생성자를 호출하는 키워드 가급적 써줘야 오류발생방지
		this.cpu = cpu;
		this.hdd = hdd;
		this.ram = ram;
		this.operationSystem = operationSystem;
	
		System.out.println("ComputerDTO 클래스의 모든 필드를 초기화하는 생성자 호출함...");
	}
	
	public ComputerDTO(String code, String brand, String name, int price, Date manufacturingDate, String cpu, int hdd, int ram, String operationSystem) {
																								// 내가가지고있는것들을 추가로 작성해서 사용가능 위와같음
		/* 부모의 모든 필드를 초기화하는 생성자로 ProductDTO클래스가 가진 필드를 초기화 할 값 전달*/
		super(code, brand, name, price, manufacturingDate);
		
		//this(cpu, hdd, ram, operationSystem); // 원래 this는 첫번째로 와야함 그렇다고 위에올리면 super 오류발생
		/* 위처럼 하고싶지만 this()로 위에 작성한 생성자를 호출한다는 의미는 super()를 두번 호출하는 것과 같기 때문에
		 * 허용되지 않는다.
		 * 부모 인스턴스를 두 개 생성할 수 없기 때문에 부모 생성자는 한 번만 호출 가능하다.
		 * */
		this.cpu = cpu;
		this.hdd = hdd;
		this.ram = ram;
		this.operationSystem = operationSystem;

		System.out.println("ComputerDTO 클래스의 부모 필드도 초기화하는 생성자 호출함..");
	}

	public String getCpu() {
		return cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public int getHdd() {
		return hdd;
	}

	public void setHdd(int hdd) {
		this.hdd = hdd;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public String getOperationSystem() {
		return operationSystem;
	}

	public void setOperationSystem(String operationSystem) {
		this.operationSystem = operationSystem;
	}

	@Override
	public String getInformation() {
							// this. 으로 해도 실행가능함 (부모것을 상속받았기 때문에)
							// 하지만 누구것인지 명확하게 하기위해서 super를 붙여 구분을해줘야함 
//		return "code = " + super.getCode()
//			+ ", brand = " + super.getBrand()
//			+ ", name = " + super.getName()
//			+ ", price = " + super.getPrice()
//			+ ", manufacturingDate = " + super.getManufacturingDate()
//			+ ", cpu = " + this.cpu
//			+ ", hdd = " + this.hdd
//			+ ", ram = " + this.ram
//			+ ", operationSystem = " + this.operationSystem;
	
				// super를 this로 바꾸면 재귀호출이 일어나서 오류발생 *주의*
		/* super.getInformation() :  정상적으로 부모의 메소드 호출
		 * this.getInformation() : 재귀호출 일어나며 stackOverflow 발생
		 * getInformation() : this.이 자동추가되어 재귀호출 발생
		 * */
		return super.getInformation()
				+ ", cpu = " + this.cpu
				+ ", hdd = " + this.hdd
				+ ", ram = " + this.ram
				+ ", operationSystem = " + this.operationSystem;
		
		//위와 아래코드 똑같은것이기때문에 둘 다 출력가능함
	}

	
	

	

	
	

}
