package com.greedy.section01.extend;

public class Car {

	
	/* 자동차의 달라는 상태를 확인할 수 있는 메소드 */
	private boolean runningStatus;

	public Car() {

		System.out.println("car 클래스의 기본 생성자 호출됨..."); 
		
	}
	
	/**
	 *<pre>
	 *자동차의 기본적인 달리는 기능
	 *</pre> 
	 */
	public void run() {
		
		runningStatus = true;
		System.out.println("자동차가 달립니다.");
	}
	
	/**
	 * <pre>
	 * 자동차의 기본적인 경적을 울리는 기능
	 * </pre>
	 */
	public void soundHorn() {
		
		if(isRunning()) { // 밑에 private boolean값을 주석처리하면 if(isRunnung)이 빨간줄이 뜨는데 그거 누르면 밑에꺼 자동생성
			
			System.out.println("빵!빵!");
		} else {
			
			System.out.println("주행중이 아닌 상태에는 경적을 울릴 수 없습니다.");
		}
	}

	/**
	 * <pre>
	 * 자동차의 주행 중 상태를 반환해주는 메소드
	 * </pre>
	 * @return true이면 주행 중인 상태이며, false이면 멈춘 상태이다.
	 */
//	private boolean isRunning() {
	protected boolean isRunning() { //private에서 protected로 변경하면 자식클래스에서 받아서 사용가능하게끔 만들어줌
						
		return runningStatus;
	}
	
	/**
	 * <pre>
	 * 자동차의 기본적인 멈추는 기능
	 * </pre>
	 */
	public void stop() {
		
		runningStatus = false;
		System.out.println("자동차가 멈춥니다.");
	}
	
}
