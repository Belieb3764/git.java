package com.ohgiraffers.hw2.run;

import java.util.Scanner;

import com.ohgiraffers.hw2.model.dto.StudentDTO;

public class Application {
	
	public static void main(String[] args) {
		
		StudentDTO stu[] = new StudentDTO[10];
		
		Scanner sc = new Scanner(System.in);
		
		int count = 0;
//		StudentDTO student =  new StudentDTO();
		
		
		while(true) {
			
			int grade = sc.nextInt();
			int classroom = sc.nextInt();
			sc.nextLine();
			String name = sc.nextLine();
			int kor = sc.nextInt();
			int eng = sc.nextInt();
			int math = sc.nextInt();
			
			stu[count] = new StudentDTO(grade, classroom, name, kor, eng, math);
			
			count ++;
				System.out.print("학생을 계속 추가하시겠습니까? : ");
			char ch = sc.next().charAt(0);
		
			if (ch =='y' || ch =='Y') {
				  continue;
			} else {
				System.out.println("프로그램이 종료됩니다.");
				 break;
			}
			
	}
//		int sum = 0;
		double avg = 0;
		for(int i = 0; i< stu.length; i++) {
			
			int sum = stu[i].getKor() + stu[i].getEng() + stu[i].getMath();
			
			avg = sum / 3;
			
			System.out.println(avg);
		}
	}
}

//			if(stu.length > 3) {
//				char ch = sc.next().charAt(0);

//				if ( )
	

