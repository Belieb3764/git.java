//package com.ohgiraffers.hw2.run;
//
//import java.util.Scanner;
//
//import com.ohgiraffers.hw2.model.dto.StudentDTO;
//
//public class Application2 {
//	
//	public static void main(String[] args) {
//		
//		// 최대 10명의 학생 정보를 기록할 수 있게 배열을 할당한다.
//		StudentDTO stu[] = new StudentDTO[10];
//		
//		Scanner sc = new Scanner(System.in);
//		// while문을 사용하여 학생들의 정보를 계속 입력 받고
//		int count = 0;
//		while(true) {
//			
//			int grade = sc.nextInt();
//			int classroom = sc.nextInt();
//			sc.nextLine();
//			String name = sc.nextLine();
//			int kor = sc.nextInt();
//			int eng = sc.nextInt();
//			int math = sc.nextInt();
//			
//			stu[count] = new StudentDTO(grade, classroom, name, kor, eng, math);
//			// 한 명씩 추가 될 때마다 카운트함
//			count++;
//			// 3명 정도의 학생 정보를 입력 받아 각 객체에 저장함
//			
//			// 계속 추가할 것인지 물어보고, 대소문자 상관없이 ‘y’이면 계속 객체 추가
//			System.out.println("계속 학생을 입력하시겠습니까? y,n");
//			char ch = sc.next().charAt(0);
//			
//			if (ch =='y' || ch =='Y') {
//				  continue;
//				} else {
//				System.out.println("프로그램이 종료됩니다.");
//				 break;
//			
//					}
//		
//			}
//			for(StudentDTO st : stu) {
//			if(st == null) {
//				break;
//			}
//			
//			int sum = st.getKor() + st.getEng() + st.getMath();
//				
//				System.out.println(st.information() + "평균 = " + sum / 3);
//			
//			// 현재 기록된 학생들의 각각의 점수 평균을 구함
//			// 학생들의 정보를 모두 출력 (평균 포함)
//		}
//		}
//}
//

